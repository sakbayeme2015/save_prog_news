"""
Django settings for ecommerce project.

For more information on this file, see
https://docs.djangoproject.com/en/1.6/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.6/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
BASE_DIR = os.path.dirname(os.path.dirname(__file__))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.6/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'n08v5x!4o3p2=o74!sa2^dozx+d4uyf^^b_(#3*3t9*^x5=c1s'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = [] 

try:
    DEFAULT_FROM_EMAIL = 'House-Online <sakbayeme2015@gmail.com>'
    EMAIL_HOST = 'smtp.sendgrid.net'  
    EMAIL_HOST_USER = 'sakbayeme2015' 
    EMAIL_HOST_PASSWORD = 'b748cd**++'
    EMAIL_PORT = 587
    EMAIL_USE_TLS = True 
except: 
    pass 

SITE_URL = "http://127.0.0.1:8000/"  
if DEBUG: 
    SITE_URL = "http://codingforentrepreneurs.com"  


# Application definition

INSTALLED_APPS = (
    'django.contrib.admin', 
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'south', 
    'accounts',
    'carts',
    'marketing',
    'orders',
    'products',
    'localflavor',
) 

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'marketing.middleware.DisplayMarketing', 
) 

ROOT_URLCONF = 'ecommerce.urls'

WSGI_APPLICATION = 'ecommerce.wsgi.application'


# Database
# https://docs.djangoproject.com/en/1.6/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.6/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Africa/Douala'

USE_I18N = True

USE_L10N = True

USE_TZ = True

MARKETING_HOURS_OFFSET = 3
MARKETING_SECONDS_OFFSET = 0
DEFAULT_TAX_RATE = 0.08


TEMPLATE_CONTEXT_PROCESSORS = (
    "django.contrib.auth.context_processors.auth",
    "django.core.context_processors.debug",
    "django.core.context_processors.i18n",
    "django.core.context_processors.media",
    "django.core.context_processors.request",
    "django.core.context_processors.static",
    "django.core.context_processors.tz",
    "django.contrib.messages.context_processors.messages",   
)



# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

STATIC_URL = '/static/' 
MEDIA_URL = '/media/'
#MEDIA_ROOT = os.path.join(BASE_DIR, "static", "media")
MEDIA_ROOT = os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "static", "media")

STATIC_ROOT = os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "static", "static_root") 
#MEDIA_ROOT = '/var/www/eCommerce1/static/media/' 

STATICFILES_DIRS = (
    os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "static", "static_files"), 
)   


TEMPLATE_DIRS = (
    os.path.join(BASE_DIR, 'templates'),
) 

STRIPE_SECRET_KEY = "sk_test_GHm5G2jzsrYebHGgqCRG5Y0a"
STRIPE_PUBLISHABLE_KEY = "pk_test_hzJDJlIMuUtMSOqPk09M5mfj" 

#live stripe key
#STRIPE_SECRET_KEY = "sk_live_HDbkcvH8JdP2ih2EPvdIFFxX"
#STRIPE_PUBLISHABLE_KEY = "pk_live_lqukE232FwPVgiWHFThaC9ra"




